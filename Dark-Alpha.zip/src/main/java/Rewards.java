
public class Rewards {
    private int credits;
    private int minerals;
    private int techPoints;

    public Rewards(int credits, int minerals, int techPoints) {
        this.credits = credits;
        this.minerals = minerals;
        this.techPoints = techPoints;
    }

    public int getCredits() { return credits; }
    public int getMinerals() { return minerals; }
    public int getTechPoints() { return techPoints; }
}
