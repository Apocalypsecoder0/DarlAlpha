
public class Tutorial {
    private Player player;
    private int currentStep;
    private List<TutorialStep> steps;
    private boolean isComplete;
    
    public Tutorial(Player player) {
        this.player = player;
        this.currentStep = 0;
        this.isComplete = false;
        initializeTutorialSteps();
    }
    
    private void initializeTutorialSteps() {
        steps = new ArrayList<>();
        steps.add(new TutorialStep("Welcome", "Welcome to Space Empire! Let's get you started."));
        steps.add(new TutorialStep("Empire Creation", "Create your first empire by choosing a name and race."));
        steps.add(new TutorialStep("Resource Management", "Learn to collect and manage resources for your empire."));
        steps.add(new TutorialStep("Fleet Building", "Build your first fleet to protect your empire."));
        steps.add(new TutorialStep("Combat", "Learn basic combat mechanics with a training battle."));
    }
    
    public TutorialStep getCurrentStep() {
        return currentStep < steps.size() ? steps.get(currentStep) : null;
    }
    
    public void progressTutorial() {
        if (currentStep < steps.size() - 1) {
            currentStep++;
        } else {
            isComplete = true;
        }
    }
    
    public boolean isComplete() {
        return isComplete;
    }
}

class TutorialStep {
    private String title;
    private String description;
    
    public TutorialStep(String title, String description) {
        this.title = title;
        this.description = description;
    }
    
    public String getTitle() { return title; }
    public String getDescription() { return description; }
}
