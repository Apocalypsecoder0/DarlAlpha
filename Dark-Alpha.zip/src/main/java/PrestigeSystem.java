
import java.util.*;

public class PrestigeSystem {
    private int prestigeLevel;
    private Map<String, Double> prestigeMultipliers;
    private List<PrestigeReward> rewards;
    
    public PrestigeSystem() {
        this.prestigeLevel = 0;
        this.prestigeMultipliers = new HashMap<>();
        this.rewards = new ArrayList<>();
        initializeMultipliers();
        initializeRewards();
    }
    
    private void initializeMultipliers() {
        prestigeMultipliers.put("DAMAGE", 0.1);
        prestigeMultipliers.put("SHIELD", 0.1);
        prestigeMultipliers.put("RESOURCES", 0.15);
        prestigeMultipliers.put("EXPERIENCE", 0.2);
    }
    
    private void initializeRewards() {
        rewards.add(new PrestigeReward("Elite Ship Blueprint", 1));
        rewards.add(new PrestigeReward("Prestige Currency", 1));
        rewards.add(new PrestigeReward("Unique Title", 2));
        rewards.add(new PrestigeReward("Special Technology", 3));
    }
    
    public boolean canPrestige(Player player) {
        return player.getLevel() >= 100;
    }
    
    public void performPrestige(Player player) {
        if (!canPrestige(player)) {
            throw new IllegalStateException("Player does not meet prestige requirements");
        }
        
        prestigeLevel++;
        resetProgress(player);
        applyPrestigeRewards(player);
    }
    
    private void resetProgress(Player player) {
        player.setLevel(1);
        player.setExperience(0);
        player.getInventory().clearNonPrestigeItems();
        player.getFleet().resetToBasicFleet();
    }
    
    private void applyPrestigeRewards(Player player) {
        for (PrestigeReward reward : rewards) {
            if (prestigeLevel >= reward.requiredPrestigeLevel) {
                reward.apply(player);
            }
        }
        
        // Apply multipliers
        for (Map.Entry<String, Double> multiplier : prestigeMultipliers.entrySet()) {
            applyMultiplier(player, multiplier.getKey(), multiplier.getValue() * prestigeLevel);
        }
    }
    
    private void applyMultiplier(Player player, String type, double value) {
        switch (type) {
            case "DAMAGE":
                player.getStats().addDamageMultiplier(value);
                break;
            case "SHIELD":
                player.getStats().addShieldMultiplier(value);
                break;
            case "RESOURCES":
                player.getStats().addResourceMultiplier(value);
                break;
            case "EXPERIENCE":
                player.getStats().addExperienceMultiplier(value);
                break;
        }
    }
    
    public int getPrestigeLevel() {
        return prestigeLevel;
    }
}

class PrestigeReward {
    private String name;
    public int requiredPrestigeLevel;
    
    public PrestigeReward(String name, int requiredPrestigeLevel) {
        this.name = name;
        this.requiredPrestigeLevel = requiredPrestigeLevel;
    }
    
    public void apply(Player player) {
        // Apply specific reward logic based on reward name
        switch (name) {
            case "Elite Ship Blueprint":
                player.getInventory().addPrestigeItem(name);
                break;
            case "Prestige Currency":
                player.addPrestigeCurrency(100 * requiredPrestigeLevel);
                break;
            case "Unique Title":
                player.addTitle("Prestige Master Level " + requiredPrestigeLevel);
                break;
            case "Special Technology":
                player.getResearchSystem().unlockPrestigeTechnology();
                break;
        }
    }
}
