public class Account {
    private String username;
    private int credits;

    public Account(String username) {
        this.username = username;
        this.credits = 0;
    }
}