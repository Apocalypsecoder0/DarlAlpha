
public class Resources {
    private int credits;
    private int minerals;
    private int energy;
    private int deuterium;

    public Resources() {
        this.credits = 1000;
        this.minerals = 500;
        this.energy = 100;
        this.deuterium = 50;
    }

    public void add(Resources other) {
        this.credits += other.credits;
        this.minerals += other.minerals;
        this.energy += other.energy;
        this.deuterium += other.deuterium;
    }

    public boolean subtract(Resources other) {
        if (canAfford(other)) {
            this.credits -= other.credits;
            this.minerals -= other.minerals;
            this.energy -= other.energy;
            this.deuterium -= other.deuterium;
            return true;
        }
        return false;
    }

    public boolean canAfford(Resources other) {
        return this.credits >= other.credits &&
               this.minerals >= other.minerals &&
               this.energy >= other.energy &&
               this.deuterium >= other.deuterium;
    }
}
