
# Dark Alpha - Space Combat Game
Engine: Dark Alpha Engine v1.0.0
Developer: Apocalypsecode0

## Installation Instructions

1. Ensure you have Java 17 or higher installed
2. Clone the repository
3. Run the following commands:

```bash
mvn clean install
java -jar target/darkalpha-1.0.0.jar
```

## System Requirements
- Java 17+
- 4GB RAM minimum
- 1GB free disk space
