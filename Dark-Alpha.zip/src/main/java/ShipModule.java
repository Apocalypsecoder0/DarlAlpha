
package main.java;

public class ShipModule {
    private String name;
    private int health;
    private boolean overheated;
    private double heatGeneration;

    public ShipModule(String name, int health) {
        this.name = name;
        this.health = health;
        this.overheated = false;
        this.heatGeneration = 10.0;
    }

    public void activate() {
        // Module activation logic
    }

    public boolean isOverheated() {
        return overheated;
    }

    public double getHeatGeneration() {
        return heatGeneration;
    }
}
