
import java.util.Map;
import java.util.HashMap;

public class ShipBlueprint {
    private Map<String, Integer> resourceRequirements = new HashMap<>();

    public Map<String, Integer> getResourceRequirements() { 
        return resourceRequirements; 
    }
    
    public void addResourceRequirement(String resource, int amount) {
        resourceRequirements.put(resource, amount);
    }
}
