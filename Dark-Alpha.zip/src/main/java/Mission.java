
public class Mission {
    private String id;
    private String type;
    private String description;
    private int rewardCredits;
    private Resources resourceRewards;
    private int requiredLevel;
    private boolean completed;
    private Map<String, Integer> objectives;
    private long deadline;

    public Mission(String id, String type, String description, int rewardCredits, int requiredLevel) {
        this.id = id;
        this.type = type;
        this.description = description;
        this.rewardCredits = rewardCredits;
        this.requiredLevel = requiredLevel;
        this.completed = false;
        this.objectives = new HashMap<>();
        this.resourceRewards = new Resources();
        this.deadline = System.currentTimeMillis() + (24 * 60 * 60 * 1000); // 24 hour deadline
    }

    public void addObjective(String objective, int target) {
        objectives.put(objective, target);
    }

    public void updateProgress(String objective, int progress) {
        if (objectives.containsKey(objective)) {
            objectives.put(objective, Math.min(objectives.get(objective), progress));
            checkCompletion();
        }
    }

    private void checkCompletion() {
        completed = objectives.values().stream().allMatch(v -> v <= 0);
    }

    public boolean isExpired() {
        return System.currentTimeMillis() > deadline;
    }

    // Getters
    public String getId() { return id; }
    public String getType() { return type; }
    public String getDescription() { return description; }
    public int getRewardCredits() { return rewardCredits; }
    public boolean isCompleted() { return completed; }
    public Map<String, Integer> getObjectives() { return objectives; }
    public Resources getResourceRewards() { return resourceRewards; }
    public int getRequiredLevel() { return requiredLevel; }
}
