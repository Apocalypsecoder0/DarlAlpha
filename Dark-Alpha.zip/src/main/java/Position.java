public class Position {
    private Coordinates3D coordinates;

    public Position(Coordinates3D coordinates) {
        this.coordinates = coordinates;
    }

    public Coordinates3D getCoordinates() {
        return coordinates;
    }
    
    public double distanceTo(Coordinates3D destination) {
        return coordinates.distanceTo(destination);
    }
}