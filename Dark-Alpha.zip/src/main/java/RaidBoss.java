
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RaidBoss extends EnemyShip {
    private int phaseCount;
    private int currentPhase;
    private Map<Integer, List<String>> phaseAbilities;
    
    public RaidBoss(String name, int level) {
        super(new Position(new Coordinates3D(0, 0, 0)));
        setHealth(level * 1000);
        this.name = name;
        this.enemyType = "RAID_BOSS";
        this.level = level;
        this.isBoss = true;
        initBossAbilities();
        this.phaseCount = 3;
        this.currentPhase = 1;
        initPhaseAbilities();
    }
    
    private void initPhaseAbilities() {
        phaseAbilities = new HashMap<>();
        phaseAbilities.put(1, Arrays.asList("Energy Drain", "Shield Matrix"));
        phaseAbilities.put(2, Arrays.asList("Fleet Summon", "Repair Drones"));
        phaseAbilities.put(3, Arrays.asList("Death Star Beam", "Total Annihilation"));
    }
    
    public void switchPhase() {
        if(currentPhase < phaseCount) {
            currentPhase++;
        }
    }
}
