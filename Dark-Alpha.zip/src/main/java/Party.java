
package main.java;

import java.util.*;

public class Party {
    private String name;
    private Player leader;
    private List<Player> members;
    private int maxSize;
    private Map<String, Integer> resourcePool;

    public Party(String name, Player leader) {
        this.name = name;
        this.leader = leader;
        this.members = new ArrayList<>();
        this.members.add(leader);
        this.maxSize = 5;
        this.resourcePool = new HashMap<>();
    }

    public boolean addMember(Player player) {
        if (members.size() < maxSize && !members.contains(player)) {
            members.add(player);
            return true;
        }
        return false;
    }

    public boolean removeMember(Player player) {
        if (player.equals(leader)) {
            if (members.size() > 1) {
                leader = members.get(1);
            }
        }
        return members.remove(player);
    }

    public void shareResources(String resourceType, int amount) {
        resourcePool.merge(resourceType, amount, Integer::sum);
    }

    public int getSharedResource(String resourceType) {
        return resourcePool.getOrDefault(resourceType, 0);
    }

    public List<Player> getMembers() { return members; }
    public Player getLeader() { return leader; }
    public String getName() { return name; }
}
