
public enum NPCRace {
    HUMAN("Human Settlers", "Versatile", 1.0, 1.0, 1.0),
    ELF("Elven Wanderers", "Ancient Magic", 1.3, 0.8, 1.1),
    HALF_ELF("Half-Elven Traders", "Diplomatic", 1.1, 0.9, 1.2),
    DWARF("Dwarven Craftsmen", "Master Smiths", 1.0, 1.2, 1.3),
    GOBLIN("Goblin Merchants", "Cunning", 0.8, 0.9, 1.4),
    BUGBEAR("Bugbear Raiders", "Fierce", 0.7, 1.4, 0.8),
    ORC("Orc Warbands", "Warlike", 0.8, 1.5, 0.7),
    HALF_ORC("Half-Orc Mercenaries", "Tough", 0.9, 1.3, 0.9),
    TIEFLING("Tiefling Outcasts", "Mysterious", 1.2, 1.0, 1.1),
    AASIMAR("Aasimar Guides", "Celestial", 1.3, 1.1, 0.9),
    HALFLING("Halfling Traders", "Resourceful", 0.9, 0.7, 1.5),
    GNOME("Gnome Tinkers", "Inventive", 1.4, 0.7, 1.2),
    GOLIATH("Goliath Nomads", "Strong", 0.7, 1.4, 0.8);

    private final String title;
    private final String trait;
    private final double techAffinity;
    private final double combatStrength;
    private final double tradingSkill;

    NPCRace(String title, String trait, double techAffinity, 
            double combatStrength, double tradingSkill) {
        this.title = title;
        this.trait = trait;
        this.techAffinity = techAffinity;
        this.combatStrength = combatStrength;
        this.tradingSkill = tradingSkill;
    }

    public String getTitle() { return title; }
    public String getTrait() { return trait; }
    public double getTechAffinity() { return techAffinity; }
    public double getCombatStrength() { return combatStrength; }
    public double getTradingSkill() { return tradingSkill; }
}
