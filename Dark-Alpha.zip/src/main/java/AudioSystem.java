public class AudioSystem {
    public void playSound(String soundFile) {
        System.out.println("Playing sound: " + soundFile);
    }

    public void playMusic(String musicFile) {
        System.out.println("Playing music: " + musicFile);
    }
}