
import java.util.*;

public class ZoneGuideSystem {
    private Map<String, List<Zone>> quadrants;
    private static final String[] QUADRANT_NAMES = {
        "Alpha Quadrant", "Beta Quadrant", "Gamma Quadrant", "Delta Quadrant"
    };
    
    public ZoneGuideSystem() {
        this.quadrants = new HashMap<>();
        initializeZones();
    }
    
    private void initializeZones() {
        for (String quadrant : QUADRANT_NAMES) {
            List<Zone> zones = new ArrayList<>();
            int zonesPerQuadrant = 18; // 72 total zones / 4 quadrants
            
            for (int i = 0; i < zonesPerQuadrant; i++) {
                int baseLevel = (i + 1) * 5; // Zones increase by 5 levels
                String zoneName = generateZoneName(quadrant, i);
                Zone zone = new Zone(zoneName, baseLevel, generateZoneType(i));
                zones.add(zone);
            }
            
            quadrants.put(quadrant, zones);
        }
    }
    
    private String generateZoneName(String quadrant, int index) {
        String[] prefixes = {
            "Nebula", "Void", "Nexus", "Storm", "Haven", "Frontier",
            "Outpost", "Stronghold", "Sanctuary", "Battleground"
        };
        
        String[] suffixes = {
            "Prime", "Core", "Expanse", "Reach", "Deep", "Sector",
            "Territory", "Zone", "Region", "Space"
        };
        
        int prefixIndex = index % prefixes.length;
        int suffixIndex = (index / 2) % suffixes.length;
        
        return String.format("%s %s %s-%d", 
            quadrant.split(" ")[0],
            prefixes[prefixIndex],
            suffixes[suffixIndex],
            index + 1);
    }
    
    private ZoneType generateZoneType(int index) {
        ZoneType[] types = ZoneType.values();
        return types[index % types.length];
    }
    
    public List<Zone> getZonesInQuadrant(String quadrant) {
        return quadrants.getOrDefault(quadrant, new ArrayList<>());
    }
    
    public Zone getZoneByLevel(int playerLevel) {
        return quadrants.values().stream()
            .flatMap(List::stream)
            .filter(zone -> zone.getLevel() <= playerLevel + 5 && zone.getLevel() >= playerLevel - 5)
            .findFirst()
            .orElse(null);
    }
}

enum ZoneType {
    COMBAT("Combat Zone", 2.0, 1.0),
    MINING("Mining Zone", 1.0, 2.0),
    EXPLORATION("Exploration Zone", 1.5, 1.5),
    TRADE("Trade Zone", 0.5, 2.5),
    DISPUTED("Disputed Zone", 3.0, 3.0),
    PEACEFUL("Peaceful Zone", 0.2, 1.0);
    
    private final String name;
    private final double combatMultiplier;
    private final double resourceMultiplier;
    
    ZoneType(String name, double combatMultiplier, double resourceMultiplier) {
        this.name = name;
        this.combatMultiplier = combatMultiplier;
        this.resourceMultiplier = resourceMultiplier;
    }
}

class Zone {
    private final String name;
    private final int level;
    private final ZoneType type;
    private List<String> recommendedShips;
    private Map<String, Double> resourceSpawnRates;
    
    public Zone(String name, int level, ZoneType type) {
        this.name = name;
        this.level = level;
        this.type = type;
        this.recommendedShips = new ArrayList<>();
        this.resourceSpawnRates = new HashMap<>();
        initializeZoneDetails();
    }
    
    private void initializeZoneDetails() {
        if (type == ZoneType.COMBAT) {
            recommendedShips.addAll(Arrays.asList("Battleship", "Destroyer", "Carrier"));
        } else if (type == ZoneType.MINING) {
            recommendedShips.addAll(Arrays.asList("Mining Vessel", "Cargo Ship", "Scout"));
        }
        
        resourceSpawnRates.put("Minerals", 0.7 * type.resourceMultiplier);
        resourceSpawnRates.put("Energy", 0.5 * type.resourceMultiplier);
        resourceSpawnRates.put("Dark Matter", 0.3 * type.resourceMultiplier);
    }
    
    public int getLevel() {
        return level;
    }
}
