import java.io.*;
import java.util.*;

public class SaveSystem {
    public static class GameData {
        private Game gameState;

        public GameData(Game game) {
            this.gameState = game;
        }

        public Game getGameState() {
            return gameState;
        }
    }

    private static final int MAX_SLOTS = 5;
    private static final String SAVE_DIR = "saves/";

    public SaveSystem() {
        new File(SAVE_DIR).mkdirs();
    }

    public void saveGame(Game game, int slot) throws IOException {
        if (slot < 1 || slot > MAX_SLOTS) {
            throw new IllegalArgumentException("Invalid save slot");
        }

        try (ObjectOutputStream oos = new ObjectOutputStream(
                new FileOutputStream(SAVE_DIR + "save_" + slot + ".dat"))) {
            GameState state = new GameState(game);
            oos.writeObject(state);
        }
    }

    public void loadGame(Game game, int slot) throws IOException, ClassNotFoundException {
        if (slot < 1 || slot > MAX_SLOTS) {
            throw new IllegalArgumentException("Invalid save slot");
        }

        try (ObjectInputStream ois = new ObjectInputStream(
                new FileInputStream(SAVE_DIR + "save_" + slot + ".dat"))) {
            GameState state = (GameState) ois.readObject();
            state.applyTo(game);
        }
    }

    public boolean saveExists(int slot) {
        return new File(SAVE_DIR + "save_" + slot + ".dat").exists();
    }
}

class GameState implements Serializable {
    private Player player;
    private Universe universe;
    private Resources resources;
    private Date saveDate;

    public GameState(Game game) {
        this.player = game.getPlayer();
        this.universe = game.getUniverse();
        this.resources = game.getResources();
        this.saveDate = new Date();
    }

    public void applyTo(Game game) {
        game.setPlayer(player);
        game.setUniverse(universe);
        game.setResources(resources);
    }
}

class SaveSystemSimplified {
    private String savePath;

    public SaveSystemSimplified(String savePath) {
        this.savePath = savePath;
    }

    public void saveGame(Game game) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(savePath))) {
            oos.writeObject(game);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Game loadGame() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(savePath))) {
            return (Game) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }
}

class Game implements Serializable{
    private Player player;
    private Universe universe;
    private Resources resources;


    public Player getPlayer() { return player;}
    public void setPlayer(Player player) {this.player = player;}

    public Universe getUniverse() { return universe;}
    public void setUniverse(Universe universe) {this.universe = universe;}

    public Resources getResources() { return resources;}
    public void setResources(Resources resources) {this.resources = resources;}
}

class Player implements Serializable{}
class Universe implements Serializable{}
class Resources implements Serializable{}