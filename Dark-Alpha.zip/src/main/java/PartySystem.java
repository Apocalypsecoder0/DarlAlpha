
package main.java;

import java.util.*;

public class PartySystem {
    private Map<String, Party> activeParties;

    public PartySystem() {
        this.activeParties = new HashMap<>();
    }

    public Party createParty(String name, Player leader) {
        if (!activeParties.containsKey(name)) {
            Party party = new Party(name, leader);
            activeParties.put(name, party);
            return party;
        }
        return null;
    }

    public void disbandParty(String name) {
        activeParties.remove(name);
    }

    public Party getParty(String name) {
        return activeParties.get(name);
    }

    public List<Party> getActiveParties() {
        return new ArrayList<>(activeParties.values());
    }
}
