
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class WorldBossManager {
    private RaidBoss currentWorldBoss;
    private Map<String, Integer> playerDamageContribution;
    private long respawnTime;
    
    public WorldBossManager() {
        this.playerDamageContribution = new HashMap<>();
        this.respawnTime = System.currentTimeMillis() + 24 * 60 * 60 * 1000; // 24 hours
    }
    
    public void spawnWorldBoss() {
        currentWorldBoss = new RaidBoss("Borg Cube", 100);
    }
    
    public void recordDamage(String playerId, int damage) {
        playerDamageContribution.merge(playerId, damage, Integer::sum);
    }
    
    public Map<String, Integer> getTopDamageContributors() {
        return playerDamageContribution.entrySet().stream()
            .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
            .limit(10)
            .collect(Collectors.toMap(
                Map.Entry::getKey,
                Map.Entry::getValue,
                (e1, e2) -> e1,
                LinkedHashMap::new
            ));
    }
}
