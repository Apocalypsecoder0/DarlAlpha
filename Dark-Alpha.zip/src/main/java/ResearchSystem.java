
public class ResearchSystem {
    private Map<String, Technology> technologies;
    private Map<String, Integer> researchLevels;
    
    public ResearchSystem() {
        this.technologies = new HashMap<>();
        this.researchLevels = new HashMap<>();
        initializeTechnologies();
    }
    
    private void initializeTechnologies() {
        technologies.put("Weapons", new Technology("Weapons", 1000));
        technologies.put("Shields", new Technology("Shields", 1000));
        technologies.put("Propulsion", new Technology("Propulsion", 1500));
        technologies.put("Mining", new Technology("Mining", 800));
    }
    
    public boolean research(String techId, int researchPoints) {
        Technology tech = technologies.get(techId);
        if (tech != null && researchPoints >= tech.getCost()) {
            int currentLevel = researchLevels.getOrDefault(techId, 0);
            researchLevels.put(techId, currentLevel + 1);
            return true;
        }
        return false;
    }
    
    public int getLevel(String techId) {
        return researchLevels.getOrDefault(techId, 0);
    }
}

class Technology {
    private String name;
    private int baseCost;
    
    public Technology(String name, int baseCost) {
        this.name = name;
        this.baseCost = baseCost;
    }
    
    public int getCost() {
        return baseCost;
    }
    
    public String getName() {
        return name;
    }
}
