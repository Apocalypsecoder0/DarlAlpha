
import java.util.Random;

public class RoguePirate extends EnemyShip {
    private String pirateType;
    private int bounty;
    private boolean isRaidLeader;
    
    public RoguePirate(String name, int level, String pirateType) {
        super(name, "PIRATE", level, false);
        this.pirateType = pirateType;
        this.bounty = calculateBounty(level);
        this.isRaidLeader = false;
        initPirateLoadout();
    }
    
    private int calculateBounty(int level) {
        return level * 1000 + new Random().nextInt(500);
    }
    
    private void initPirateLoadout() {
        setHealth(getHealth() * 1.2); // Pirates are tougher
        setShields(getShields() * 1.1);
        // Pirates deal more damage
        setAttack(getAttack() * 1.3);
    }
    
    @Override
    public int calculateDamage() {
        int baseDamage = super.calculateDamage();
        // Pirates have a chance for critical hits
        if (new Random().nextDouble() < 0.2) {
            return (int)(baseDamage * 1.5);
        }
        return baseDamage;
    }
    
    public int getBounty() {
        return bounty;
    }
}
