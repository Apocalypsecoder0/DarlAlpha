
public class Stats {
    // Base Stats
    private int miningEfficiency;
    private int tradingEfficiency;
    private int researchEfficiency;
    private int combatEfficiency;
    private int diplomacySkill;
    
    // Advanced Combat Stats
    private int shieldPower;
    private int weaponPrecision;
    private int evasion;
    private int criticalHitChance;
    
    // Resource Management Stats
    private int energyManagement;
    private int resourceStorage;
    private int productionSpeed;
    
    // Bonuses and Multipliers
    private double experienceMultiplier;
    private double resourceMultiplier;
    private double combatMultiplier;

    public Stats() {
        initializeBaseStats();
        initializeAdvancedStats();
        initializeMultipliers();
    }

    private void initializeBaseStats() {
        this.miningEfficiency = 10;
        this.tradingEfficiency = 10;
        this.researchEfficiency = 10;
        this.combatEfficiency = 10;
        this.diplomacySkill = 10;
    }

    private void initializeAdvancedStats() {
        this.shieldPower = 100;
        this.weaponPrecision = 75;
        this.evasion = 50;
        this.criticalHitChance = 5;
        this.energyManagement = 100;
        this.resourceStorage = 1000;
        this.productionSpeed = 100;
    }

    private void initializeMultipliers() {
        this.experienceMultiplier = 1.0;
        this.resourceMultiplier = 1.0;
        this.combatMultiplier = 1.0;
    }

    public void increaseStats() {
        miningEfficiency++;
        tradingEfficiency++;
        researchEfficiency++;
        combatEfficiency++;
        diplomacySkill++;
    }

    public void increaseCombatStats(int amount) {
        shieldPower += amount;
        weaponPrecision += amount;
        evasion += (amount / 2);
        criticalHitChance += (amount / 5);
    }

    public void applyTemporaryBoost(String statType, double multiplier, int duration) {
        switch (statType) {
            case "EXPERIENCE":
                experienceMultiplier *= multiplier;
                break;
            case "RESOURCE":
                resourceMultiplier *= multiplier;
                break;
            case "COMBAT":
                combatMultiplier *= multiplier;
                break;
        }
        // Duration handling would be managed by a separate timer system
    }

    // Getters
    public int getMiningEfficiency() { return (int)(miningEfficiency * resourceMultiplier); }
    public int getTradingEfficiency() { return tradingEfficiency; }
    public int getResearchEfficiency() { return researchEfficiency; }
    public int getCombatEfficiency() { return (int)(combatEfficiency * combatMultiplier); }
    public int getDiplomacySkill() { return diplomacySkill; }
    public int getShieldPower() { return shieldPower; }
    public int getWeaponPrecision() { return weaponPrecision; }
    public int getEvasion() { return evasion; }
    public int getCriticalHitChance() { return criticalHitChance; }
    public int getEnergyManagement() { return energyManagement; }
    public int getResourceStorage() { return resourceStorage; }
    public int getProductionSpeed() { return productionSpeed; }
    
    // Calculate combat power
    public int calculateCombatPower() {
        return (int)((shieldPower + weaponPrecision + evasion * 2 + criticalHitChance * 3) * combatMultiplier);
    }
    
    // Calculate resource efficiency
    public int calculateResourceEfficiency() {
        return (int)((miningEfficiency + energyManagement + resourceStorage) * resourceMultiplier);
    }

    // Activity effects system
    private Map<String, ActivityEffect> activeEffects = new HashMap<>();

    public class ActivityEffect {
        private String name;
        private String description;
        private Map<String, Double> statModifiers;
        private int duration;

        public ActivityEffect(String name, String description, Map<String, Double> statModifiers, int duration) {
            this.name = name;
            this.description = description;
            this.statModifiers = statModifiers;
            this.duration = duration;
        }

        public void applyEffect() {
            for (Map.Entry<String, Double> modifier : statModifiers.entrySet()) {
                switch (modifier.getKey()) {
                    case "COMBAT":
                        combatMultiplier *= modifier.getValue();
                        break;
                    case "RESOURCE":
                        resourceMultiplier *= modifier.getValue();
                        break;
                    case "EXPERIENCE":
                        experienceMultiplier *= modifier.getValue();
                        break;
                }
            }
        }

        public void removeEffect() {
            for (Map.Entry<String, Double> modifier : statModifiers.entrySet()) {
                switch (modifier.getKey()) {
                    case "COMBAT":
                        combatMultiplier /= modifier.getValue();
                        break;
                    case "RESOURCE":
                        resourceMultiplier /= modifier.getValue();
                        break;
                    case "EXPERIENCE":
                        experienceMultiplier /= modifier.getValue();
                        break;
                }
            }
        }

        public void decreaseDuration() {
            duration--;
        }

        public boolean isExpired() {
            return duration <= 0;
        }

        public String getDescription() {
            return description;
        }
    }

    public void addActivityEffect(String name, String description, Map<String, Double> modifiers, int duration) {
        ActivityEffect effect = new ActivityEffect(name, description, modifiers, duration);
        effect.applyEffect();
        activeEffects.put(name, effect);
    }

    public void updateEffects() {
        Iterator<Map.Entry<String, ActivityEffect>> iterator = activeEffects.entrySet().iterator();
        while (iterator.hasNext()) {
            ActivityEffect effect = iterator.next().getValue();
            effect.decreaseDuration();
            if (effect.isExpired()) {
                effect.removeEffect();
                iterator.remove();
            }
        }
    }

    public String getActiveEffectsDescription() {
        StringBuilder description = new StringBuilder();
        for (ActivityEffect effect : activeEffects.values()) {
            description.append("- ").append(effect.getDescription()).append("\n");
        }
        return description.toString();
    }
}
