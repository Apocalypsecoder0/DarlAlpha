
import java.util.*;
import java.time.LocalDateTime;

public class MarketSystem {
    private Map<String, Map<String, List<MarketOrder>>> regionalMarkets;
    private Map<String, List<Double>> priceHistory;
    private Map<String, Double> marketVolume;
    
    public MarketSystem() {
        this.regionalMarkets = new HashMap<>();
        this.priceHistory = new HashMap<>();
        this.marketVolume = new HashMap<>();
    }
    
    public void placeOrder(String region, MarketOrder order) {
        regionalMarkets.computeIfAbsent(region, k -> new HashMap<>())
                      .computeIfAbsent(order.getItemId(), k -> new ArrayList<>())
                      .add(order);
        updatePriceHistory(order);
        processMarketManipulation(region, order);
    }

    private void processMarketManipulation(String region, MarketOrder order) {
        double volume = marketVolume.getOrDefault(order.getItemId(), 0.0);
        marketVolume.put(order.getItemId(), volume + order.getQuantity());
        
        if (marketVolume.get(order.getItemId()) > 1000) {
            adjustRegionalPrice(region, order.getItemId(), 0.95); // Price depression
        }
    }
    
    private void adjustRegionalPrice(String region, String itemId, double factor) {
        List<MarketOrder> orders = regionalMarkets.get(region).get(itemId);
        orders.forEach(order -> order.setPrice(order.getPrice() * factor));
    }
}

class MarketOrder {
    private String itemId;
    private double price;
    private int quantity;
    private boolean isBuyOrder;
    private LocalDateTime timestamp;
    private String region;
    
    public MarketOrder(String itemId, double price, int quantity, boolean isBuyOrder, String region) {
        this.itemId = itemId;
        this.price = price;
        this.quantity = quantity;
        this.isBuyOrder = isBuyOrder;
        this.timestamp = LocalDateTime.now();
        this.region = region;
    }
    
    public String getItemId() { return itemId; }
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
    public int getQuantity() { return quantity; }
    public String getRegion() { return region; }
}
