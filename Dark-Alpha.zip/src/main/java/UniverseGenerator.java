import java.util.ArrayList;
import java.util.List;
import java.util.Random;

class Sector {
    int x;
    int y;
    int riskLevel;
    String name;

    public Sector(int x, int y, int riskLevel, String name) {
        this.x = x;
        this.y = y;
        this.riskLevel = riskLevel;
        this.name = name;
    }
}

public class UniverseGenerator {

    private static final int SECTOR_GRID_SIZE = 10; // Example size
    private List<Sector> sectors = new ArrayList<>();

    private int calculateRiskLevel(int x, int y) {
        //Some logic to calculate risk level
        return (x + y) % 5;
    }

    private void initializeSectors() {
        Random random = new Random();
        int sectorIndex = 0;

        for (int x = 0; x < SECTOR_GRID_SIZE; x++) {
            for (int y = 0; y < SECTOR_GRID_SIZE; y++) {
                String sectorName = generateSectorName(sectorIndex);
                sectors.add(new Sector(x, y, calculateRiskLevel(x, y), sectorName));
                sectorIndex++;
            }
        }
    }

    private String generateSectorName(int index) {
        String[] sectorPrefixes = {
            "Deep Space", "Neutral Zone", "Disputed Territory",
            "Frontier", "Border", "Core", "Trade Route"
        };

        String[] sectorSuffixes = {
            "Alpha", "Beta", "Gamma", "Delta", "Epsilon",
            "Zeta", "Eta", "Theta", "Iota", "Kappa"
        };

        Random random = new Random();
        return sectorPrefixes[random.nextInt(sectorPrefixes.length)] + " " +
               sectorSuffixes[index % sectorSuffixes.length] + "-" + (index + 1);
    }


    public static void main(String[] args) {
        UniverseGenerator generator = new UniverseGenerator();
        generator.initializeSectors();
        for (Sector sector : generator.sectors) {
            System.out.println("Sector Name: " + sector.name + ", Risk Level: " + sector.riskLevel);
        }
    }
}