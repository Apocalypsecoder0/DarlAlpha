
public class RaceTalentTree {
    private Map<String, RaceTalent> combatTalents;
    private Map<String, RaceTalent> techTalents;
    private Map<String, RaceTalent> tradeTalents;

    public RaceTalentTree(Map<String, RaceTalent> combatTalents, 
                         Map<String, RaceTalent> techTalents,
                         Map<String, RaceTalent> tradeTalents) {
        this.combatTalents = combatTalents;
        this.techTalents = techTalents;
        this.tradeTalents = tradeTalents;
    }

    public boolean unlockTalent(String talentId, int experience) {
        RaceTalent talent = findTalent(talentId);
        if (talent != null && !talent.isUnlocked() && canUnlock(talent, experience)) {
            talent.unlock();
            return true;
        }
        return false;
    }

    private RaceTalent findTalent(String talentId) {
        if (combatTalents.containsKey(talentId)) return combatTalents.get(talentId);
        if (techTalents.containsKey(talentId)) return techTalents.get(talentId);
        if (tradeTalents.containsKey(talentId)) return tradeTalents.get(talentId);
        return null;
    }

    private boolean canUnlock(RaceTalent talent, int experience) {
        return experience >= (talent.getTier() * 1000);
    }

    public List<RaceTalent> getAvailableTalents(int level) {
        List<RaceTalent> available = new ArrayList<>();
        addAvailableTalents(available, combatTalents, level);
        addAvailableTalents(available, techTalents, level);
        addAvailableTalents(available, tradeTalents, level);
        return available;
    }

    private void addAvailableTalents(List<RaceTalent> available, Map<String, RaceTalent> talents, int level) {
        talents.values().stream()
            .filter(t -> t.getTier() <= level && !t.isUnlocked())
            .forEach(available::add);
    }
}
