import java.util.*;

class Coordinates3D {
    private double x, y, z;

    public Coordinates3D(double x, double y, double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public double distanceTo(Coordinates3D other) {
        return Math.sqrt(Math.pow(x - other.x, 2) + 
                        Math.pow(y - other.y, 2) + 
                        Math.pow(z - other.z, 2));
    }
}

class Stargate {
    private String id;
    private Coordinates3D location;
    private boolean active;
    private Set<String> connectedGates;
    private int energyLevel;

    public Stargate(String id, Coordinates3D location) {
        this.id = id;
        this.location = location;
        this.active = false;
        this.connectedGates = new HashSet<>();
        this.energyLevel = 100;
    }

    public boolean dialGate(Stargate destination) {
        if (energyLevel < 20) return false;
        this.active = true;
        this.connectedGates.add(destination.id);
        this.energyLevel -= 20;
        return true;
    }
}

class HyperspaceDrive {
    private int charge;
    private int maxRange;
    private boolean cooldown;

    public HyperspaceDrive(int maxRange) {
        this.charge = 100;
        this.maxRange = maxRange;
        this.cooldown = false;
    }

    public boolean jumpToHyperspace(Ship ship, Coordinates3D destination) {
        if (cooldown || charge < 25) return false;
        double distance = ship.getPosition().distanceTo(destination);
        if (distance > maxRange) return false;

        charge -= 25;
        cooldown = true;
        return true;
    }
}

class JumpGate {
    private String id;
    private Coordinates3D location;
    private List<JumpGate> network;
    private int stabilityField;

    public JumpGate(String id, Coordinates3D location) {
        this.id = id;
        this.location = location;
        this.network = new ArrayList<>();
        this.stabilityField = 100;
    }

    public boolean initiateJump(Ship ship, JumpGate destination) {
        if (stabilityField < 30) return false;
        if (!network.contains(destination)) return false;

        stabilityField -= 10;
        return true;
    }
}

class ImpulseDrive {
    private int fuelLevel;
    private int maxSpeed;

    public ImpulseDrive(int maxSpeed) {
        this.fuelLevel = 100;
        this.maxSpeed = maxSpeed;
    }

    public boolean activateImpulse(Coordinates3D destination) {
        if (fuelLevel < 10) return false;
        // Simulate impulse travel
        fuelLevel -= 10;
        return true;
    }

    public int getFuelLevel() {
        return fuelLevel;
    }
}

// Ship class implementation moved to Ship.java


public class SpaceTransport {
    private Map<String, Stargate> stargates;
    private Map<String, JumpGate> jumpGates;

    public SpaceTransport() {
        this.stargates = new HashMap<>();
        this.jumpGates = new HashMap<>();
        initializeNetwork();
    }

    private void initializeNetwork() {
        // Create initial network of stargates and jump gates
        Stargate alpha = new Stargate("SG-Alpha", new Coordinates3D(0, 0, 0));
        Stargate beta = new Stargate("SG-Beta", new Coordinates3D(100, 100, 100));
        stargates.put("SG-Alpha", alpha);
        stargates.put("SG-Beta", beta);

        JumpGate prime = new JumpGate("JG-Prime", new Coordinates3D(50, 50, 50));
        JumpGate secondary = new JumpGate("JG-Secondary", new Coordinates3D(150, 150, 150));
        jumpGates.put("JG-Prime", prime);
        jumpGates.put("JG-Secondary", secondary);
    }

    public void jumpToGate(String gateName) {
        System.out.println("Jumping to jump gate: " + gateName);
    }

    public void engageImpulse(Ship ship, Coordinates3D destination) {
        if (ship != null) {
            ship.getImpulseDrive().activateImpulse(destination);
        }
    }
}