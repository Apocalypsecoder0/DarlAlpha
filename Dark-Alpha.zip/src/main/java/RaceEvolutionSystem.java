import java.util.*;

public class RaceEvolutionSystem {
    private Map<String, RaceTalentTree> talentTrees;
    private Map<String, Integer> raceExperience;
    private static final int TIER_1_THRESHOLD = 1000;
    private static final int TIER_2_THRESHOLD = 5000;
    private static final int TIER_3_THRESHOLD = 10000;

    public RaceEvolutionSystem() {
        this.talentTrees = new HashMap<>();
        this.raceExperience = new HashMap<>();
        initializeTalentTrees();
    }

    private void initializeTalentTrees() {
        // Combat specialization talents
        Map<String, RaceTalent> combatTalents = new HashMap<>();
        combatTalents.put("enhanced_weapons", new RaceTalent("Enhanced Weapons", 1, 0.1));
        combatTalents.put("advanced_shields", new RaceTalent("Advanced Shields", 2, 0.15));
        combatTalents.put("superior_tactics", new RaceTalent("Superior Tactics", 3, 0.2));

        // Tech specialization talents
        Map<String, RaceTalent> techTalents = new HashMap<>();
        techTalents.put("research_mastery", new RaceTalent("Research Mastery", 1, 0.1));
        techTalents.put("efficient_engineering", new RaceTalent("Efficient Engineering", 2, 0.15));
        techTalents.put("breakthrough_innovations", new RaceTalent("Breakthrough Innovations", 3, 0.2));

        // Trade specialization talents
        Map<String, RaceTalent> tradeTalents = new HashMap<>();
        tradeTalents.put("negotiation_skills", new RaceTalent("Negotiation Skills", 1, 0.1));
        tradeTalents.put("market_influence", new RaceTalent("Market Influence", 2, 0.15));
        tradeTalents.put("trade_empire", new RaceTalent("Trade Empire", 3, 0.2));

        for (Major_Powers_Race race : Major_Powers_Race.values()) {
            talentTrees.put(race.name(), new RaceTalentTree(combatTalents, techTalents, tradeTalents));
        }
    }

    public boolean unlockTalent(String raceName, String talentId) {
        RaceTalentTree tree = talentTrees.get(raceName);
        if (tree != null) {
            int exp = raceExperience.getOrDefault(raceName, 0);
            return tree.unlockTalent(talentId, exp);
        }
        return false;
    }

    public void gainExperience(String raceName, int amount) {
        int currentExp = raceExperience.getOrDefault(raceName, 0);
        raceExperience.put(raceName, currentExp + amount);
    }

    public int getRaceLevel(String raceName) {
        int exp = raceExperience.getOrDefault(raceName, 0);
        if (exp >= TIER_3_THRESHOLD) return 3;
        if (exp >= TIER_2_THRESHOLD) return 2;
        if (exp >= TIER_1_THRESHOLD) return 1;
        return 0;
    }

    public List<RaceTalent> getAvailableTalents(String raceName) {
        RaceTalentTree tree = talentTrees.get(raceName);
        return tree != null ? tree.getAvailableTalents(getRaceLevel(raceName)) : new ArrayList<>();
    }
}

class RaceTalentTree {
    private String raceName;
    private Map<String, RaceTalent> talents;
    private Set<String> unlockedTalents;
    private Map<String, RaceTalent> combatTalents;
    private Map<String, RaceTalent> techTalents;
    private Map<String, RaceTalent> tradeTalents;


    public RaceTalentTree(Map<String, RaceTalent> combatTalents, Map<String, RaceTalent> techTalents, Map<String, RaceTalent> tradeTalents) {
        this.combatTalents = combatTalents;
        this.techTalents = techTalents;
        this.tradeTalents = tradeTalents;
        this.talents = new HashMap<>();
        this.unlockedTalents = new HashSet<>();
        this.talents.putAll(combatTalents);
        this.talents.putAll(techTalents);
        this.talents.putAll(tradeTalents);

    }

    public boolean unlockTalent(String talentName, int currentExp) {
        RaceTalent talent = talents.get(talentName);
        if (talent != null && currentExp >= (talent.getTier() * 1000) && !unlockedTalents.contains(talentName)) {
            unlockedTalents.add(talentName);
            return true;
        }
        return false;
    }
    public List<RaceTalent> getAvailableTalents(int level) {
        List<RaceTalent> availableTalents = new ArrayList<>();
        for (RaceTalent talent : talents.values()) {
            if (talent.getTier() == level && !unlockedTalents.contains(talent.getName())) {
                availableTalents.add(talent);
            }
        }
        return availableTalents;
    }
}

class RaceTalent {
    private String name;
    private int tier;
    private double effect;


    public RaceTalent(String name, int tier, double effect) {
        this.name = name;
        this.tier = tier;
        this.effect = effect;
    }

    public String getName() {
        return name;
    }

    public int getTier() {
        return tier;
    }
    public double getEffect() { return effect; }
}

enum Major_Powers_Race {
    HUMANS,
    ELVES,
    DWARVES,
    ORCS;

    public String name() { return this.name(); }
}