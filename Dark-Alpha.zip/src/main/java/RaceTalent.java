
public class RaceTalent {
    private String name;
    private int tier;
    private double bonus;
    private boolean unlocked;

    public RaceTalent(String name, int tier, double bonus) {
        this.name = name;
        this.tier = tier;
        this.bonus = bonus;
        this.unlocked = false;
    }

    public String getName() { return name; }
    public int getTier() { return tier; }
    public double getBonus() { return bonus; }
    public boolean isUnlocked() { return unlocked; }
    public void unlock() { this.unlocked = true; }
}
