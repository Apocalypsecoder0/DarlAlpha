
package main.java;

public class Ship {
    private String name;
    private String role;
    private int health;
    private int shields;
    private int attack;
    private int level;
    private Position position;
    private ImpulseDrive impulseDrive;

    public static enum Position {
        FRONT, MIDDLE, BACK
    }

    public Ship(String name) {
        this.name = name;
        this.level = 1;
        this.impulseDrive = new ImpulseDrive();
        initializeShipStats();
    }

    private void initializeShipStats() {
        switch(name.toLowerCase()) {
            case "destroyer":
                role = "Assault";
                health = 80;
                shields = 40;
                attack = 35;
                position = Position.FRONT;
                break;
            case "battleship":
                role = "Tank";
                health = 120;
                shields = 60;
                attack = 25;
                position = Position.FRONT;
                break;
            case "cruiser":
                role = "Support";
                health = 90;
                shields = 50;
                attack = 20;
                position = Position.MIDDLE;
                break;
            default:
                role = "Scout";
                health = 100;
                shields = 50;
                attack = 25;
                position = Position.BACK;
        }
    }

    public int getHealth() { return health; }
    public void setHealth(int health) { this.health = health; }
    public int getShields() { return shields; }
    public void setShields(int shields) { this.shields = shields; }
    public int getAttack() { return attack; }
    public String getName() { return name; }
    public Position getPosition() { return position; }
    public ImpulseDrive getImpulseDrive() { return impulseDrive; }
}
