
public class Shipyard {
    private List<ShipBlueprint> availableBlueprints;
    private Map<String, Integer> resourceRequirements;
    private int buildCapacity;
    private List<BuildOrder> currentOrders;

    public Shipyard(int buildCapacity) {
        this.buildCapacity = buildCapacity;
        this.availableBlueprints = new ArrayList<>();
        this.currentOrders = new ArrayList<>();
        this.resourceRequirements = new HashMap<>();
        initializeBlueprints();
    }

    private void initializeBlueprints() {
        // Add basic ship blueprints
        Map<String, Integer> destroyerReqs = new HashMap<>();
        destroyerReqs.put("Metal", 1000);
        destroyerReqs.put("Energy", 500);
        availableBlueprints.add(new ShipBlueprint("Destroyer", destroyerReqs, 3600)); // 1 hour build time
    }

    public boolean startShipConstruction(String blueprintName, Player player) {
        ShipBlueprint blueprint = findBlueprint(blueprintName);
        if (blueprint == null || currentOrders.size() >= buildCapacity) return false;

        // Check resources
        for (Map.Entry<String, Integer> req : blueprint.getResourceRequirements().entrySet()) {
            if (!player.getInventory().useResource(req.getKey(), req.getValue())) {
                return false;
            }
        }

        BuildOrder order = new BuildOrder(blueprint, System.currentTimeMillis());
        currentOrders.add(order);
        return true;
    }

    public List<Ship> checkCompletedShips() {
        List<Ship> completedShips = new ArrayList<>();
        Iterator<BuildOrder> iterator = currentOrders.iterator();
        
        while (iterator.hasNext()) {
            BuildOrder order = iterator.next();
            if (order.isComplete()) {
                completedShips.add(new Ship(order.getBlueprint().getName()));
                iterator.remove();
            }
        }
        return completedShips;
    }

    private ShipBlueprint findBlueprint(String name) {
        return availableBlueprints.stream()
            .filter(bp -> bp.getName().equals(name))
            .findFirst()
            .orElse(null);
    }
}

class ShipBlueprint {
    private String name;
    private Map<String, Integer> resourceRequirements;
    private long buildTime; // in milliseconds

    public ShipBlueprint(String name, Map<String, Integer> resourceRequirements, long buildTime) {
        this.name = name;
        this.resourceRequirements = resourceRequirements;
        this.buildTime = buildTime;
    }

    public String getName() { return name; }
    public Map<String, Integer> getResourceRequirements() { return resourceRequirements; }
    public long getBuildTime() { return buildTime; }
}

class BuildOrder {
    private ShipBlueprint blueprint;
    private long startTime;

    public BuildOrder(ShipBlueprint blueprint, long startTime) {
        this.blueprint = blueprint;
        this.startTime = startTime;
    }

    public boolean isComplete() {
        return System.currentTimeMillis() - startTime >= blueprint.getBuildTime();
    }

    public ShipBlueprint getBlueprint() { return blueprint; }
}
